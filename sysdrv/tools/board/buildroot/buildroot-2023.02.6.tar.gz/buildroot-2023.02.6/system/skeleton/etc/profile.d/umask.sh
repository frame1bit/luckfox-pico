umask 022
